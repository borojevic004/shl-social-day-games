const SHLSocialSimulator = (() => {
  const els = {
    step: document.getElementById("simulator-step"),
    stage: document.getElementById("simulator-stage"),
    actions: document.getElementById("simulator-actions")
  };

  const prepByAttribute = {
    action: ["Mut mitbringen", "Sicherheitsregeln beachten"],
    active: ["Bequeme Schuhe", "Wasserflasche einpacken"],
    administration: ["Unterlagen sortieren", "Ruhig nachfragen"],
    animals: ["Ruhige Stimme", "Vorsichtig mit Tieren umgehen"],
    care: ["Geduld mitbringen", "Freundlich helfen"],
    children: ["Gute Laune", "Bastelidee vorbereiten"],
    cleaning: ["Handschuhe tragen", "Sorgfaeltig arbeiten"],
    communication: ["Klare Fragen stellen", "Gut zuhoeren"],
    creative: ["Eigene Ideen", "Material bereitlegen"],
    culture: ["Neugierig sein", "Besucher*innen helfen"],
    customerContact: ["Freundlich begruessen", "Aufmerksam bleiben"],
    design: ["Farben pruefen", "Ideen skizzieren"],
    detail: ["Genau hinschauen", "In Ruhe kontrollieren"],
    education: ["Einfach erklaeren", "Geduldig bleiben"],
    entertainment: ["Gute Stimmung", "Ueberblick behalten"],
    fastPaced: ["Schnell reagieren", "Trotzdem ruhig bleiben"],
    firstAid: ["Ruhig bleiben", "Hilfe holen"],
    food: ["Haende waschen", "Arbeitsflaeche sauber halten"],
    fun: ["Gute Energie", "Teamgeist"],
    health: ["Hygiene beachten", "Diskret bleiben"],
    history: ["Interessiert fragen", "Infos merken"],
    hospitality: ["Gaeste begruessen", "Service freundlich halten"],
    hygiene: ["Haende waschen", "Sauber arbeiten"],
    leadership: ["Aufgaben verteilen", "Verantwortung uebernehmen"],
    library: ["Leise arbeiten", "Buecher sortieren"],
    logistics: ["Ordnung halten", "Richtig tragen"],
    media: ["Notizen machen", "Kreativ denken"],
    museum: ["Leise erklaeren", "Auf Ausstellungsstuecke achten"],
    nature: ["Wetterfeste Kleidung", "Auf Pflanzen achten"],
    office: ["Notizen machen", "Konzentriert arbeiten"],
    organization: ["Plan lesen", "Dinge sortieren"],
    outdoor: ["Feste Schuhe", "Wetter checken"],
    patience: ["Geduldig bleiben", "Langsam erklaeren"],
    people: ["Freundlich sein", "Nach Hilfe fragen"],
    performance: ["Selbstbewusst auftreten", "Vorher ueben"],
    physical: ["Richtig heben", "Pausen machen"],
    plants: ["Vorsichtig giessen", "Pflanzen erkennen"],
    preparation: ["Alles bereitlegen", "Ablauf verstehen"],
    problemSolving: ["Problem beschreiben", "Schritt fuer Schritt denken"],
    quiet: ["Ruhig arbeiten", "Konzentriert bleiben"],
    repair: ["Werkzeug pruefen", "Genau arbeiten"],
    responsibility: ["Verlaesslich sein", "Bescheid sagen"],
    safety: ["Auf Sicherheit achten", "Regeln befolgen"],
    sales: ["Freundlich beraten", "Geld ordentlich zaehlen"],
    seniors: ["Langsam sprechen", "Geduldig helfen"],
    service: ["Laecheln", "Aufmerksam sein"],
    sport: ["Fair bleiben", "In Bewegung bleiben"],
    support: ["Problem verstehen", "Ruhig helfen"],
    teamwork: ["Absprechen", "Zusammen helfen"],
    technical: ["Werkzeug sortieren", "Genau schauen"],
    technology: ["Geraet pruefen", "Loesung erklaeren"],
    tools: ["Werkzeug sicher nutzen", "Aufraeumen"],
    youth: ["Respektvoll sprechen", "Ideen sammeln"]
  };

  const taskByAttribute = {
    animals: ["Futter vorbereiten", "Tiere beobachten"],
    children: ["Spiel vorbereiten", "Beim Basteln helfen"],
    cleaning: ["Arbeitsplatz sauber machen", "Material wegräumen"],
    creative: ["Idee gestalten", "Material sortieren"],
    food: ["Zutaten vorbereiten", "Theke auffuellen"],
    health: ["Wartebereich ordnen", "Hygiene beachten"],
    media: ["Fotoidee sammeln", "Kurzen Text schreiben"],
    nature: ["Pflanzen giessen", "Draussen mithelfen"],
    office: ["Liste pruefen", "Dokumente sortieren"],
    people: ["Person begruessen", "Freundlich weiterhelfen"],
    sales: ["Ware einraeumen", "Kund*innen begruessen"],
    service: ["Bestellung vorbereiten", "Bereich sauber halten"],
    sport: ["Station aufbauen", "Team anfeuern"],
    technical: ["Werkzeug bereitlegen", "Kleine Reparatur vorbereiten"],
    teamwork: ["Mit Team absprechen", "Gemeinsam Aufgabe loesen"]
  };

  const neutralPrep = [
    "Frueh genug da sein",
    "Handy weglegen",
    "Pausen absprechen",
    "Team begruessen",
    "Fragen stellen"
  ];

  const neutralTasks = [
    "Kurz mit dem Team absprechen",
    "Aufgabe erklaeren lassen",
    "Arbeitsplatz ordentlich halten",
    "Nachfragen, wenn etwas unklar ist",
    "Zum Schluss Danke sagen"
  ];

  const impactMessages = [
    "Damit unterstuetzt du Jugend- und Bildungsprojekte von SHL.",
    "So wird aus einem Arbeitstag echte Hilfe fuer andere junge Menschen.",
    "Genau darum geht es beim Sozialen Tag: arbeiten, Lohn spenden, gemeinsam etwas bewegen."
  ];

  let selectedJob = null;
  let selectedPrep = [];
  let doneTasks = [];
  let previousJobIds = [];

  function shuffle(items) {
    return [...items].sort(() => Math.random() - 0.5);
  }

  function safeJobs() {
    return typeof jobs !== "undefined" && Array.isArray(jobs) ? jobs : [];
  }

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function setStep(number, title) {
    if (els.step) els.step.textContent = `Schritt ${number} von 4`;
    if (els.actions) els.actions.innerHTML = "";
    if (els.stage) {
      els.stage.innerHTML = `<h2 class="simulator-title">${escapeHtml(title)}</h2>`;
    }
  }

  function tagsFor(job) {
    const labels = typeof attributeLabels !== "undefined" ? attributeLabels : {};
    return (job.attributes || [])
      .slice(0, 4)
      .map((attribute) => `<span>${escapeHtml(labels[attribute] || attribute)}</span>`)
      .join("");
  }

  function jobImage(job) {
    if (!job.image) {
      return `<div class="simulator-image-fallback">${escapeHtml(job.title)}</div>`;
    }

    return `<img class="simulator-job-image" src="${escapeHtml(job.image)}" alt="${escapeHtml(job.title)}" loading="lazy" />`;
  }

  function pickJobs() {
    const allJobs = safeJobs();
    const unseen = allJobs.filter((job) => !previousJobIds.includes(job.id));
    const pool = unseen.length >= 3 ? unseen : allJobs;
    const picks = shuffle(pool).slice(0, 3);
    previousJobIds = picks.map((job) => job.id);
    return picks;
  }

  function renderJobChoice() {
    setStep(1, "Such dir deinen Tag aus");
    const picks = pickJobs();

    if (!picks.length) {
      els.stage.insertAdjacentHTML("beforeend", `<p class="simulator-copy">Keine Jobs gefunden. Bitte pruefe data/jobs.js.</p>`);
      return;
    }

    els.stage.insertAdjacentHTML(
      "beforeend",
      `<p class="simulator-copy">Waehle einen Job und spiele kurz durch, wie dein Sozialer Tag ablaufen koennte.</p>
      <div class="simulator-job-grid">
        ${picks.map((job) => `
          <button class="simulator-job-card" type="button" data-job-id="${job.id}">
            ${jobImage(job)}
            <strong>${escapeHtml(job.title)}</strong>
            <small>${escapeHtml(job.group || "Sozialer Tag Job")}</small>
            <span class="simulator-tags">${tagsFor(job)}</span>
          </button>
        `).join("")}
      </div>`
    );

    els.stage.querySelectorAll("[data-job-id]").forEach((button) => {
      button.addEventListener("click", () => {
        selectedJob = safeJobs().find((job) => String(job.id) === button.dataset.jobId) || picks[0];
        selectedPrep = [];
        doneTasks = [];
        renderPrep();
      });
    });
  }

  function prepOptions() {
    const fromAttributes = (selectedJob.attributes || [])
      .flatMap((attribute) => prepByAttribute[attribute] || [])
      .filter((item, index, list) => list.indexOf(item) === index);

    return shuffle([...fromAttributes, ...neutralPrep])
      .filter((item, index, list) => list.indexOf(item) === index)
      .slice(0, 8);
  }

  function renderPrep() {
    setStep(2, "Bereite dich vor");
    const options = prepOptions();

    els.stage.insertAdjacentHTML(
      "beforeend",
      `<p class="simulator-copy">Tippe drei Dinge an, die dir bei <strong>${escapeHtml(selectedJob.title)}</strong> helfen.</p>
      <div class="simulator-chip-grid">
        ${options.map((option) => `<button class="simulator-chip" type="button" data-prep="${escapeHtml(option)}">${escapeHtml(option)}</button>`).join("")}
      </div>`
    );

    els.actions.innerHTML = `<button class="simulator-next" type="button" disabled>Weiter</button>`;
    const next = els.actions.querySelector(".simulator-next");

    els.stage.querySelectorAll("[data-prep]").forEach((button) => {
      button.addEventListener("click", () => {
        const value = button.dataset.prep;
        if (selectedPrep.includes(value)) {
          selectedPrep = selectedPrep.filter((item) => item !== value);
          button.classList.remove("is-selected");
        } else if (selectedPrep.length < 3) {
          selectedPrep.push(value);
          button.classList.add("is-selected");
        }

        next.disabled = selectedPrep.length !== 3;
      });
    });

    next.addEventListener("click", renderWorkday);
  }

  function taskOptions() {
    const fromAttributes = (selectedJob.attributes || [])
      .flatMap((attribute) => taskByAttribute[attribute] || [])
      .filter((item, index, list) => list.indexOf(item) === index);

    return [...fromAttributes, ...neutralTasks].slice(0, 5);
  }

  function renderWorkday() {
    setStep(3, "Jetzt geht dein Tag los");
    const tasks = taskOptions();

    els.stage.insertAdjacentHTML(
      "beforeend",
      `<p class="simulator-copy">Erledige die Aufgaben. Jede kleine Aufgabe bringt deinen Sozialen Tag weiter.</p>
      <div class="simulator-progressbar"><span></span></div>
      <div class="simulator-task-list">
        ${tasks.map((task, index) => `<button class="simulator-task" type="button" data-task="${index}">${escapeHtml(task)}</button>`).join("")}
      </div>`
    );

    const progress = els.stage.querySelector(".simulator-progressbar span");
    els.stage.querySelectorAll("[data-task]").forEach((button) => {
      button.addEventListener("click", () => {
        const task = button.dataset.task;
        if (doneTasks.includes(task)) return;

        doneTasks.push(task);
        button.classList.add("is-done");
        button.textContent = `Erledigt: ${button.textContent}`;
        progress.style.width = `${(doneTasks.length / tasks.length) * 100}%`;

        if (doneTasks.length === tasks.length) {
          els.actions.innerHTML = `<button class="simulator-next" type="button">Tag abschliessen</button>`;
          els.actions.querySelector(".simulator-next").addEventListener("click", renderFinal);
        }
      });
    });
  }

  function earnedAmount() {
    return 18 + ((Number(selectedJob.id) * 7) % 16) + selectedPrep.length;
  }

  function renderFinal() {
    setStep(4, "Dein Einsatz zaehlt");
    const amount = earnedAmount();
    const message = impactMessages[Number(selectedJob.id) % impactMessages.length];

    els.stage.insertAdjacentHTML(
      "beforeend",
      `<div class="simulator-final">
        ${jobImage(selectedJob)}
        <div class="simulator-amount">${amount} EUR</div>
        <p class="simulator-copy"><strong>${escapeHtml(selectedJob.title)}</strong> geschafft! Dein erarbeiteter Lohn wird gespendet.</p>
        <p class="simulator-impact">${escapeHtml(message)}</p>
        <div class="simulator-summary">
          ${selectedPrep.map((item) => `<span>${escapeHtml(item)}</span>`).join("")}
        </div>
      </div>`
    );

    els.actions.innerHTML = `
      <button class="simulator-next" type="button" id="simulator-restart">Nochmal spielen</button>
      <button class="simulator-home" type="button" id="simulator-home">Zur Startseite</button>
    `;

    els.actions.querySelector("#simulator-restart").addEventListener("click", start);
    els.actions.querySelector("#simulator-home").addEventListener("click", () => {
      if (typeof SHLConfetti !== "undefined") SHLConfetti.clear();
      SHLApp.showScreen("home");
    });

    if (typeof SHLConfetti !== "undefined") {
      SHLConfetti.start({
        mode: "burst",
        count: 220,
        lifetime: 5200,
        minSize: 4,
        maxSize: 18,
        minRadius: 90,
        maxRadius: 300,
        minDuration: 2.6,
        maxDuration: 4.4,
        maxDelay: 0.35,
        originSpreadX: 4,
        originSpreadY: 4,
        minFall: 220,
        maxFall: 520,
        fallDrift: 190
      });
    }
  }

  function start() {
    selectedJob = null;
    selectedPrep = [];
    doneTasks = [];
    renderJobChoice();
  }

  function init() {
    if (!els.step || !els.stage || !els.actions || typeof SHLApp === "undefined") return;
    SHLApp.onStartSimulator(start);
    SHLApp.onBackSimulator(() => {
      selectedJob = null;
      selectedPrep = [];
      doneTasks = [];
    });
  }

  return { init, start };
})();

SHLSocialSimulator.init();
